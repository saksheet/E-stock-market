package com.example.companyreg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockregApplicationTests {

	@Test
	void contextLoads() {
	}

}
