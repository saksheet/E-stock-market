package com.example.companyreg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockregApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockregApplication.class, args);
	}

}
